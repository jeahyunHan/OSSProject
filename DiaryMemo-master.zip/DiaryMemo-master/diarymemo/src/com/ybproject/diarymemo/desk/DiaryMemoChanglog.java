/**
 * 파일명: DiaryMemoBugreport.java
 * 최종수정: 2012년 2월 25일
 * 수정자: 이용범(top6616@gmail.com)
 * 설명: 버그리포트 페이지 이동
 * TODO: desk 를 한개로 묶어 버릴 수 없나...
 */
package com.ybproject.diarymemo.desk;

import com.ybproject.diarymemo.R;

import android.app.*;
import android.content.Intent;
import android.os.*;

public class DiaryMemoChanglog extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.changlog);

	}
}