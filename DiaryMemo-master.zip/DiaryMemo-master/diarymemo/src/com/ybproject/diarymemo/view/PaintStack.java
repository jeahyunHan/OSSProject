package com.ybproject.diarymemo.view;


public class PaintStack {

	float size;
	int color;
	
	
	public PaintStack()
	{	
	}


	public float getSize() {
		return size;
	}


	public void setSize(float size) {
		this.size = size;
	}


	public int getColor() {
		return color;
	}


	public void setColor(int color) {
		this.color = color;
	}
	
}
