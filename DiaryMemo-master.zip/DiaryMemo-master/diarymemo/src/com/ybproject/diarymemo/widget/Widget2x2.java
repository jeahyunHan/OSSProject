package com.ybproject.diarymemo.widget;

public class Widget2x2 extends DiaryMemoWidgetProvider2x {
}
