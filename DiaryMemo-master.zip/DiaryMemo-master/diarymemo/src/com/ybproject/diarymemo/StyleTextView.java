package com.ybproject.diarymemo;

import android.content.Context;
import android.widget.TextView;

public class StyleTextView extends TextView{
	public StyleTextView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

}
